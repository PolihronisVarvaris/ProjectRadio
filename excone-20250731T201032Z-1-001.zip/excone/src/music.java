/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.*;

/**
 *
 * @author polih
 */
public class music {

    /*static String driverClassName= "org.apache.derby.jdbc.ClientDriver";
    static String url = "jdbc:derby://localhost:1527/dblabs";
    static Connection dbConnection = null;
    static String username="";
    static String passwd = "";
    public static void main (String [] argv) throws Exception
    {
        Class.forName (driverClassName);
        dbConnection= DriverManager.getConnection(url, username , passwd);
        dbConnection.close();
    }
    */
    
    
}
