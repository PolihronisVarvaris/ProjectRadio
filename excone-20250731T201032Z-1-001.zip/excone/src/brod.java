import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class brod extends javax.swing.JFrame {

    
    public brod() {
        initComponents();
        myconnection();
        mylist();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        resultTable = new javax.swing.JTable();
        optionsArea = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        resultTable.setBackground(new java.awt.Color(0, 0, 0));
        resultTable.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        resultTable.setForeground(new java.awt.Color(255, 255, 255));
        resultTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Show"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        resultTable.setGridColor(new java.awt.Color(255, 0, 0));
        jScrollPane1.setViewportView(resultTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 200, -1, 220));

        optionsArea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optionsAreaActionPerformed(evt);
            }
        });
        getContentPane().add(optionsArea, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 140, 160, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Producer name ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 140, 140, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/logocol.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("D:\\TBΔ\\finito\\5.png")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        setSize(new java.awt.Dimension(978, 587));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        this.setVisible(false);
        new cat().setVisible(true); 
    }//GEN-LAST:event_jLabel3MouseClicked


    private void optionsAreaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optionsAreaActionPerformed
        DefaultTableModel model = (DefaultTableModel) resultTable.getModel();
        model.setRowCount(0);
        String selected = String.valueOf(optionsArea.getSelectedItem());
        try {
            selectPROGRAM.setString(1, selected);
            rs = selectPROGRAM.executeQuery();
            
            while(rs.next()) {
		String show = rs.getString("PBROADCAST");
                Object[] row = { show};
                model.addRow(row);
                /*int time = rs.getInt("P_TIME");
                Object[] row = { time};
                String genre = rs.getString("P_GENRE");
                Object[] row = { genre};
                model.addRow(row);*/
            }
            if (model.getRowCount() == 0 && rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "no data", 
                        "Ενημέρωση", JOptionPane.INFORMATION_MESSAGE);
                System.out.println("no data");
            }
        } catch(SQLException ex) {
            System.out.println("\n -- SQL Exception --- \n");
            while(ex != null) {
		System.out.println("Message: " + ex.getMessage());
		ex = ex.getNextException();
            }
        }
    }//GEN-LAST:event_optionsAreaActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(brod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(brod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(brod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(brod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new brod().setVisible(true);
            }
        });
    }


    void myconnection() {
        try{
           Class.forName(driverClassName);
        }catch (ClassNotFoundException ex){
        }
        try{
        dbConnection = DriverManager.getConnection(url, username,passwd);
        String insertString = "insert into PROGRAM (PBROADCAST, PTIME, PGENRE, PPRODUCER) values (?, ?, ?, ?)";
        selectPROGRAM = dbConnection.prepareStatement(insertString);
        }catch(SQLException ex){
            System.out.println("\n -- SQL Exception ----- \n");
            while (ex != null){
                System.out.println("Message: " + ex.getMessage());
                ex = ex.getNextException();
            }
        }
   }

    void mylist(){
        int i=0;
        String Producername="SELECT DISTINCT PPRODUCER FROM PROGRAM";
        try{
            statment = dbConnection.createStatement();
            rs=statment.executeQuery(Producername);
            while(rs.next()){
                myProducers[i]=rs.getString("PPRODUCER");
                i++;
            }
        }catch(SQLException ex) {   
            System.out.println("\n -- SQL Exception - \n");
            while(ex != null) {
                System.out.println("Message: " + ex.getMessage());
                ex = ex.getNextException();
            }
        }
        optionsArea.addItem("");
        for (int y=0;y<i;y++) {
        optionsArea.addItem(myProducers[y]);
        }
    }

    static String driverClassName= "oracle.jdbc.OracleDriver";
    static String url = "jdbc:oracle:thin:@192.168.6.21:1521:dblabs";
    static Connection dbConnection = null;
    static String username="it185152";
    static String passwd = "pv2000120";
    static Statement statment = null;
    static PreparedStatement selectPROGRAM = null;
    String myProducers[] = new String[10];
    static ResultSet rs	= null;


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> optionsArea;
    private javax.swing.JTable resultTable;
    // End of variables declaration//GEN-END:variables
}
